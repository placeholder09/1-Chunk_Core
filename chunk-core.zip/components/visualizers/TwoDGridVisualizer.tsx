import React, { useEffect } from 'react';
import { GameSettings, Stimulus } from '../../types';
import { COLORS, SHAPES, LETTERS } from '../../constants';

interface VisualizerProps {
  stimulus: Stimulus | null;
  settings: GameSettings;
  onVisualStimulusArrival: () => void;
}

const TwoDGridVisualizer: React.FC<VisualizerProps> = ({ stimulus, settings, onVisualStimulusArrival }) => {
  const gridSize = settings.gridSize;
  const gridCells = Array.from({ length: gridSize * gridSize }, (_, i) => i);
  const activePosition = stimulus?.visual?.position;
  
  useEffect(() => {
    if (stimulus) {
      onVisualStimulusArrival();
    }
  }, [stimulus, onVisualStimulusArrival]);

  return (
    <div className="w-full h-full flex items-center justify-center p-4">
        <div 
            className="grid gap-2 w-full max-w-md"
            style={{
                aspectRatio: '1 / 1',
                gridTemplateColumns: `repeat(${gridSize}, minmax(0, 1fr))`,
                gridTemplateRows: `repeat(${gridSize}, minmax(0, 1fr))`,
            }}
        >
          {gridCells.map(index => {
            const isActive = activePosition === index;
            const activeStimulus = isActive ? stimulus!.visual : null;
            
            const ShapeComponent = (isActive && activeStimulus && settings.stimuli.shape.enabled) 
              ? SHAPES[activeStimulus.shape % SHAPES.length] 
              : null;
            
            const LetterComponent = (isActive && activeStimulus && settings.stimuli.text.enabled)
              ? LETTERS[activeStimulus.text % LETTERS.length]
              : null;

            const highlightColor = (isActive && activeStimulus && settings.stimuli.color.enabled) 
              ? COLORS[activeStimulus.color % COLORS.length] 
              : '#3B82F6'; // Default blue-500

            const cellStyle: React.CSSProperties = {
                backgroundColor: isActive ? highlightColor : 'transparent'
            };
            
            return (
              <div
                key={index}
                className="aspect-square border border-slate-400 rounded-md flex items-center justify-center transition-all duration-200 relative"
                style={cellStyle}
              >
                {ShapeComponent && (
                  <div className="w-3/4 h-3/4 text-white" style={{opacity: LetterComponent ? 0.7 : 1}}>
                    <ShapeComponent />
                  </div>
                )}
                 {LetterComponent && (
                  <div className="absolute text-white font-bold text-4xl" style={{ textShadow: '0 0 5px black' }}>
                    {LetterComponent}
                  </div>
                )}
              </div>
            );
          })}
        </div>
    </div>
  );
};

export default TwoDGridVisualizer;