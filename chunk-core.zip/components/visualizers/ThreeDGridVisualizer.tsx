import React, { useEffect } from 'react';
import { GameSettings, Stimulus } from '../../types';
import { SHAPES, COLORS, LETTERS } from '../../constants';

interface VisualizerProps {
  stimulus: Stimulus | null;
  settings: GameSettings;
  onVisualStimulusArrival: () => void;
}

const GridFace: React.FC<{ 
    activeCell: number | null;
    gridSize: number;
    stimulus: Stimulus | null;
    settings: GameSettings;
}> = ({ activeCell, gridSize, stimulus, settings }) => {
    return (
        <div 
          className="grid gap-1 w-full h-full p-1"
          style={{
              gridTemplateColumns: `repeat(${gridSize}, 1fr)`,
              gridTemplateRows: `repeat(${gridSize}, 1fr)`
          }}
        >
            {Array.from({ length: gridSize * gridSize }).map((_, i) => {
                const isActive = activeCell === i;
                const ShapeComponent = isActive && stimulus && settings.stimuli.shape.enabled 
                  ? SHAPES[stimulus.visual!.shape % SHAPES.length] 
                  : null;
                
                const LetterComponent = isActive && stimulus && settings.stimuli.text.enabled
                  ? LETTERS[stimulus.visual!.text % LETTERS.length]
                  : null;

                const highlightColor = (isActive && stimulus && settings.stimuli.color.enabled)
                  ? COLORS[stimulus.visual!.color % COLORS.length]
                  : '#3B82F6'; // Default blue-500

                const cellStyle: React.CSSProperties = {
                    backgroundColor: isActive ? highlightColor : 'transparent',
                    boxShadow: isActive ? `0 0 10px 2px ${highlightColor}` : 'none',
                    borderColor: 'rgba(147, 197, 253, 0.5)', // Brighter blue-300/50
                }

                return (
                    <div key={i} className={`border rounded-sm transition-colors duration-200 flex items-center justify-center relative`} style={cellStyle}>
                         {ShapeComponent && (
                            <div className="w-3/4 h-3/4 text-white" style={{opacity: LetterComponent ? 0.7 : 1}}>
                                <ShapeComponent />
                            </div>
                         )}
                         {LetterComponent && (
                            <div className="absolute text-white font-bold text-lg xl:text-xl" style={{ textShadow: '0 0 5px black' }}>
                                {LetterComponent}
                            </div>
                        )}
                    </div>
                )
            })}
        </div>
    )
}

const ThreeDGridVisualizer: React.FC<VisualizerProps> = ({ stimulus, settings, onVisualStimulusArrival }) => {
  const gridSize = settings.gridSize;
  const cellsPerFace = gridSize * gridSize;
  const activePosition = stimulus?.visual?.position;
  const baseSize = 300;
  const halfSize = baseSize / 2;
  
  useEffect(() => {
    if (stimulus) {
      onVisualStimulusArrival();
    }
  }, [stimulus, onVisualStimulusArrival]);

  const faces = [
    { transform: `rotateY(0deg) translateZ(${halfSize}px)`, key: 'front' },
    { transform: `rotateY(180deg) translateZ(${halfSize}px)`, key: 'back' },
    { transform: `rotateY(90deg) translateZ(${halfSize}px)`, key: 'right' },
    { transform: `rotateY(-90deg) translateZ(${halfSize}px)`, key: 'left' },
    { transform: `rotateX(90deg) translateZ(${halfSize}px)`, key: 'top' },
    { transform: `rotateX(-90deg) translateZ(${halfSize}px)`, key: 'bottom' },
  ];
  
  return (
    <div className="w-full h-full perspective-container flex items-center justify-center">
      <div 
        className="relative rotating-cube" 
        style={{ 
          width: `${baseSize}px`,
          height: `${baseSize}px`,
          transformStyle: 'preserve-3d',
          '--camera-angle-x': `${settings.cameraAngleX}deg`
        } as React.CSSProperties}
      >
        {faces.map((face, index) => {
            const faceIndex = activePosition != null ? Math.floor(activePosition / cellsPerFace) : -1;
            const activeCellForFace = faceIndex === index ? activePosition! % cellsPerFace : null;

            return (
              <div
                key={face.key}
                className="absolute border-2 border-blue-300 bg-slate-800/50"
                style={{ 
                    transform: face.transform,
                    width: `${baseSize}px`,
                    height: `${baseSize}px`,
                }}
              >
                 <GridFace 
                    activeCell={activeCellForFace} 
                    gridSize={gridSize}
                    stimulus={stimulus}
                    settings={settings}
                />
              </div>
            )
        })}
      </div>
    </div>
  );
};

export default ThreeDGridVisualizer;