

import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { GameSettings, Stimulus, StimulusType, VisualMode, UserResponse, PerformanceStats, VisualStimulus, TurnFeedback, AudioGUIVisibility, ResponseLayout } from '../types';
import { TONES, LETTERS } from '../constants';
import TwoDGridVisualizer from './visualizers/TwoDGridVisualizer';
import ThreeDCubeVisualizer from './visualizers/ThreeDCubeVisualizer';
import ThreeDGridVisualizer from './visualizers/ThreeDGridVisualizer';
import ThreeDSpheresVisualizer from './visualizers/ThreeDSpheresVisualizer';

interface GameProps {
  settings: GameSettings;
  gameState: 'idle' | 'running' | 'paused' | 'finished';
  performance: PerformanceStats;
  onGameStart: () => void;
  onGamePause: () => void;
  onGameStop: () => void;
  onGameFinish: () => void;
  onPerformanceUpdate: (stats: PerformanceStats) => void;
}

let audioContext: AudioContext | null = null;
const playTone = (frequency: number) => {
  if (!audioContext) {
    audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  if (audioContext.state === 'suspended') {
    audioContext.resume();
  }
  const oscillator = audioContext.createOscillator();
  const gainNode = audioContext.createGain();
  oscillator.connect(gainNode);
  gainNode.connect(audioContext.destination);
  
  oscillator.type = 'sine';
  oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime);
  
  const startTime = audioContext.currentTime;
  gainNode.gain.setValueAtTime(0.3, startTime);
  gainNode.gain.exponentialRampToValueAtTime(0.0001, startTime + 0.3);
  
  oscillator.start(startTime);
  oscillator.stop(startTime + 0.3);
};

// Represents a full trial: the chunk to memorize, and the item to test against.
interface TrialData {
    chunk: Stimulus[];
    testItem: Stimulus;
    isMatch: boolean;
}

const Game: React.FC<GameProps> = ({ settings, gameState, performance, onGameStart, onGamePause, onGameStop, onGameFinish, onPerformanceUpdate }) => {
  const [trialData, setTrialData] = useState<TrialData | null>(null);
  const [currentStimulus, setCurrentStimulus] = useState<Stimulus | null>(null);
  const [turn, setTurn] = useState(0); // Overall trial number
  const [subTurn, setSubTurn] = useState(0); // Step within a trial (0 to N for chunk, N+1 for test)
  const [userResponses, setUserResponses] = useState<Partial<Record<StimulusType, UserResponse>>>({});
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [isFeedbackPhase, setIsFeedbackPhase] = useState(false);
  const [turnFeedback, setTurnFeedback] = useState<Partial<Record<StimulusType, TurnFeedback>>>({});
  const [statusText, setStatusText] = useState('Ready');
  const timeoutRef = useRef<number | null>(null);

  const activeStimuli = useMemo(() => 
    Object.entries(settings.stimuli)
      .filter(([, val]) => val.enabled)
      .map(([key]) => key as StimulusType), 
  [settings.stimuli]);

  const generateSingleStimulus = useCallback((): Stimulus => {
    const newStimulus: Stimulus = { id: Date.now() + Math.random(), audio: null, visual: null };
    
    const size = settings.gridSize;
    const maxPos = {
        [VisualMode.TwoDGrid]: size * size,
        [VisualMode.ThreeDGrid]: 6 * size * size,
        [VisualMode.ThreeDCube]: size * size * size,
        [VisualMode.ThreeDSpheres]: 6 * size * size,
    }[settings.visualMode];

    const useRandomPosition = settings.visualMode === VisualMode.ThreeDGrid || settings.visualMode === VisualMode.ThreeDSpheres;
    
    if (settings.stimuli.audio.enabled) {
        newStimulus.audio = Math.floor(Math.random() * settings.stimuli.audio.count);
    }
    if (settings.stimuli.position.enabled) {
        const positionCount = useRandomPosition ? maxPos : Math.min(settings.stimuli.position.count, maxPos);
        newStimulus.visual = {
            position: Math.floor(Math.random() * positionCount),
            color: settings.stimuli.color.enabled ? Math.floor(Math.random() * settings.stimuli.color.count) : 0,
            shape: settings.stimuli.shape.enabled ? Math.floor(Math.random() * settings.stimuli.shape.count) : 0,
            text: settings.stimuli.text.enabled ? Math.floor(Math.random() * settings.stimuli.text.count) : 0,
        };
    }
    return newStimulus;
  }, [settings]);

  // New function to generate a full trial based on the user's "chunk-then-test" logic
  const generateTrial = useCallback((): TrialData => {
    const chunk: Stimulus[] = [];
    for (let i = 0; i < settings.nValue; i++) {
        chunk.push(generateSingleStimulus());
    }

    const isMatchTrial = Math.random() > 0.5;
    let testItem: Stimulus;
    let isMatchInTrial = false;

    if (isMatchTrial) {
        // Pick a random stimulus from the generated chunk to be the test item.
        const matchIndex = Math.floor(Math.random() * chunk.length);
        const matchingStimulus = chunk[matchIndex];
        testItem = { ...matchingStimulus, id: Date.now() + Math.random() }; // Ensure unique ID
        isMatchInTrial = true;
    } else {
        // Generate a new stimulus, ensuring it doesn't match anything in the chunk.
        let attempt = 0;
        while (true) {
            testItem = generateSingleStimulus();
            const collision = activeStimuli.some(stimulusType => {
                if (stimulusType === 'audio') {
                    return chunk.some(s => s.audio === testItem.audio);
                } else {
                    const testVal = testItem.visual?.[stimulusType as keyof VisualStimulus];
                    return chunk.some(s => s.visual?.[stimulusType as keyof VisualStimulus] === testVal);
                }
            });

            if (!collision || attempt > 50) {
                break; // Found a unique stimulus or gave up
            }
            attempt++;
        }
    }
    
    return { chunk, testItem, isMatch: isMatchInTrial };
  }, [settings.nValue, generateSingleStimulus, activeStimuli]);

  const startNextTrial = useCallback(() => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    setIsFeedbackPhase(false);
    setTurnFeedback({});
    setUserResponses({});
    setSubTurn(0);
    setTurn(t => t + 1);
    const newTrialData = generateTrial();
    setTrialData(newTrialData);
  }, [generateTrial]);

  const handleVisualStimulusArrival = useCallback(() => {
    if (gameState !== 'running' || !currentStimulus) return;
  
    if (settings.stimuli.audio.enabled && currentStimulus.audio !== null) {
      playTone(TONES[currentStimulus.audio]);
    }
  }, [currentStimulus, gameState, settings.stimuli.audio.enabled]);

  // Main game loop logic - rewritten for discrete trials
  useEffect(() => {
    if (gameState !== 'running' || !trialData) return;
    
    if (turn > settings.trials) {
        onGameFinish();
        return;
    }
    
    // Phase 1: Present the chunk to be memorized
    if (subTurn < settings.nValue) {
        setStatusText(`Memorize ${subTurn + 1}/${settings.nValue}`);
        const stimToPresent = trialData.chunk[subTurn];
        setCurrentStimulus(stimToPresent);
        // Audio is now played via onVisualStimulusArrival callback

        timeoutRef.current = window.setTimeout(() => {
            setSubTurn(s => s + 1);
        }, settings.speed);
    } 
    // Phase 2: Present the test item and wait for response
    else if (subTurn === settings.nValue) {
        setStatusText('Respond');
        const stimToPresent = trialData.testItem;
        setCurrentStimulus(stimToPresent);
        // Audio is now played via onVisualStimulusArrival callback
        setIsEvaluating(true);
        // Stop and wait for user to submit
    }

  }, [gameState, turn, subTurn, trialData, settings, onGameFinish]);


  useEffect(() => {
    if (gameState === 'running' && turn === 0) {
      startNextTrial();
    }
    if (gameState !== 'running') {
      if(timeoutRef.current) clearTimeout(timeoutRef.current);
    }
     if (gameState === 'idle') {
      setTurn(0);
      setSubTurn(0);
      setTrialData(null);
      setCurrentStimulus(null);
      setStatusText('Ready');
    }

    return () => {
      if(timeoutRef.current) clearTimeout(timeoutRef.current);
    }
  }, [gameState, startNextTrial]);
  
  useEffect(() => {
     if (gameState === 'finished') setStatusText(`Finished! Score: ${performance.overallAccuracy.toFixed(1)}%`);
     else if (gameState === 'paused') setStatusText('Paused');
  }, [gameState, performance.overallAccuracy]);

  const handleResponse = (stimulusType: StimulusType, response: UserResponse) => {
    setUserResponses(prev => ({...prev, [stimulusType]: response}));
  };

  const submitResponses = () => {
    if (!isEvaluating || !trialData) return;

    const newScores = {...(performance.scores || {})};
    let correctResponsesInTurn = 0;
    const feedback: Partial<Record<StimulusType, TurnFeedback>> = {};

    activeStimuli.forEach(stimulusType => {
        let isMatch = false;
        
        if (stimulusType === 'audio') {
            const currentAudio = trialData.testItem.audio;
            if (currentAudio !== null) {
                isMatch = trialData.chunk.some(s => s.audio === currentAudio);
            }
        } else { // position, color, shape, text
            const currentVal = trialData.testItem.visual?.[stimulusType as keyof VisualStimulus];
            if (currentVal !== undefined && trialData.testItem.visual) {
                isMatch = trialData.chunk.some(s => s.visual?.[stimulusType as keyof VisualStimulus] === currentVal);
            }
        }
        
        const correctResponse: UserResponse = isMatch ? 'match' : 'new';
        const userResp = userResponses[stimulusType] || 'new'; // Default to 'new' if no response
        
        feedback[stimulusType] = { userResponse: userResp, correctResponse };
        
        if (!newScores[stimulusType]) newScores[stimulusType] = { correct: 0, total: 0 };
        newScores[stimulusType]!.total++;
        if (userResp === correctResponse) {
            newScores[stimulusType]!.correct++;
            correctResponsesInTurn++;
        }
    });
    
    setTurnFeedback(feedback);
    const turnWasPerfect = correctResponsesInTurn === activeStimuli.length;
    if (turnWasPerfect) setStatusText('Perfect!');
    else setStatusText('Results');

    const newCurrentStreak = turnWasPerfect ? performance.currentStreak + 1 : 0;

    const newStats: PerformanceStats = {
      scores: newScores,
      currentStreak: newCurrentStreak,
      bestStreak: Math.max(performance.bestStreak, newCurrentStreak),
      accuracies: {},
      overallAccuracy: 0,
    };
    
    let totalCorrect = 0;
    let totalPossible = 0;
    Object.values(newScores).forEach(s => {
        totalCorrect += s.correct;
        totalPossible += s.total;
    });
    Object.keys(newScores).forEach(key => {
        const sKey = key as StimulusType;
        newStats.accuracies[sKey] = (newScores[sKey]!.correct / newScores[sKey]!.total) * 100;
    });
    newStats.overallAccuracy = totalPossible > 0 ? (totalCorrect / totalPossible) * 100 : 0;
    
    onPerformanceUpdate(newStats);
    setIsEvaluating(false);
    setIsFeedbackPhase(true);
    timeoutRef.current = window.setTimeout(startNextTrial, 1500);
  };
  
  const Visualizer = useMemo(() => {
    switch (settings.visualMode) {
      case VisualMode.TwoDGrid: return TwoDGridVisualizer;
      case VisualMode.ThreeDCube: return ThreeDCubeVisualizer;
      case VisualMode.ThreeDGrid: return ThreeDGridVisualizer;
      case VisualMode.ThreeDSpheres: return ThreeDSpheresVisualizer;
      default: return TwoDGridVisualizer;
    }
  }, [settings.visualMode]);
  
  const isSubmitDisabled = !isEvaluating || Object.keys(userResponses).length < activeStimuli.length || gameState !== 'running';

  const getButtonClass = (stimulusType: StimulusType, responseType: UserResponse) => {
    if (isFeedbackPhase) {
        const feedback = turnFeedback[stimulusType];
        if (!feedback) return 'bg-gray-200 opacity-50';

        const wasChosen = feedback.userResponse === responseType;
        const wasCorrect = feedback.correctResponse === responseType;

        if (wasChosen && wasCorrect) return 'bg-green-500 text-white ring-2 ring-green-300';
        if (wasChosen && !wasCorrect) return 'bg-red-500 text-white ring-2 ring-red-300';
        if (!wasChosen && wasCorrect) return 'bg-gray-200 ring-2 ring-green-500'; // Show correct answer
        return 'bg-gray-200 opacity-50';
    }

    const isSelected = userResponses[stimulusType] === responseType;
    return isSelected ? 'bg-blue-500 text-white' : 'bg-gray-200 hover:bg-gray-300';
  }
  
  const getActiveStimuliText = () => {
    const visuals = ['color', 'shape', 'text'].filter(s => settings.stimuli[s as keyof typeof settings.stimuli].enabled);
    if(visuals.length === 0) return '';
    return ` + ${visuals.map(s => s.charAt(0).toUpperCase() + s.slice(1)).join(' + ')}`;
  }

  const showSubmit = isEvaluating || isFeedbackPhase;
  const showAudioUI = settings.stimuli.audio.enabled && settings.audioGUIVisibility !== AudioGUIVisibility.Hidden;
  const showAudioText = settings.audioGUIVisibility === AudioGUIVisibility.IconAndText;

  const visualizerContent = (
      <div 
        className="w-full flex-grow flex flex-col bg-slate-800 rounded-md p-4 min-h-0"
        style={{ minHeight: `${settings.visualizerHeight}px` }}
      >
        <h3 className="text-center font-semibold text-slate-300 flex-shrink-0 py-2">
          {settings.visualMode} ({settings.gridSize}x{settings.gridSize}{settings.visualMode !== VisualMode.TwoDGrid && `x${settings.gridSize}`})
          {getActiveStimuliText()}
        </h3>
        <div className="w-full flex-grow flex items-center justify-center relative min-h-0">
          <Visualizer 
              stimulus={currentStimulus} 
              settings={settings}
              onVisualStimulusArrival={handleVisualStimulusArrival}
            />
        </div>
        <div className="flex-shrink-0 w-full flex justify-center items-center min-h-[100px]">
            {showAudioUI && (
                <div className="text-center">
                    {showAudioText && <h4 className="font-semibold text-slate-300 mb-2">Audio Tones</h4>}
                    <div className="w-16 h-16 bg-slate-700 rounded-full flex items-center justify-center mx-auto">
                        <svg className="w-8 h-8 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2z"></path></svg>
                    </div>
                </div>
            )}
        </div>
      </div>
  );

  const responseButtons = (
      <div className={`grid gap-x-4 gap-y-6 ${settings.responseLayout === ResponseLayout.Side ? 'grid-cols-1' : 'grid-cols-1 sm:grid-cols-2'}`}>
          {activeStimuli.map(stimulusType => (
            <div key={stimulusType} className="text-center">
                <h4 className="font-semibold capitalize mb-2">{stimulusType} Response</h4>
                <div className="space-y-2">
                    <button onClick={() => handleResponse(stimulusType, 'match')} disabled={!isEvaluating || gameState !== 'running'} className={`w-full py-2 rounded-md font-bold transition-all duration-200 text-sm ${getButtonClass(stimulusType, 'match')} disabled:opacity-50 disabled:cursor-not-allowed`}>MATCH</button>
                    <button onClick={() => handleResponse(stimulusType, 'new')} disabled={!isEvaluating || gameState !== 'running'} className={`w-full py-2 rounded-md font-bold transition-all duration-200 text-sm ${getButtonClass(stimulusType, 'new')} disabled:opacity-50 disabled:cursor-not-allowed`}>NEW</button>
                </div>
            </div>
          ))}
      </div>
  );

  const submitButton = (
    <>
      {showSubmit && gameState !== 'idle' && (
           <button onClick={submitResponses} disabled={isSubmitDisabled} className={`w-full font-semibold bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition-colors duration-300 text-lg tracking-widest disabled:bg-blue-300 disabled:cursor-not-allowed ${settings.responseLayout === ResponseLayout.Bottom ? 'mt-4' : ''} ${isEvaluating && !isSubmitDisabled ? 'animate-pulse-strong' : ''}`}>
              SUBMIT
          </button>
      )}
    </>
  );

  return (
    <div className="flex flex-col h-full">
      <header className="flex justify-between items-center mb-4 pb-4 border-b border-gray-200">
        <div className="flex space-x-6 text-sm">
          <p>Trial: <span className="font-bold">{gameState === 'idle' ? '0' : Math.min(turn, settings.trials)} / {settings.trials}</span></p>
          <p>N-Back Level: <span className="font-bold">{settings.nValue}</span></p>
          <p>Status: <span className="font-bold">{statusText}</span></p>
        </div>
        <div className="flex space-x-2">
            <button onClick={onGameStart} disabled={gameState === 'running'} className="px-4 py-2 text-sm font-semibold text-white bg-blue-600 rounded-md shadow-sm hover:bg-blue-700 disabled:bg-blue-300 disabled:cursor-not-allowed">Start</button>
            <button onClick={onGamePause} disabled={gameState !== 'running' && gameState !== 'paused'} className="px-4 py-2 text-sm font-semibold text-gray-700 bg-gray-200 rounded-md shadow-sm hover:bg-gray-300 disabled:bg-gray-100">{gameState === 'paused' ? 'Resume' : 'Pause'}</button>
            <button onClick={onGameStop} disabled={gameState === 'idle'} className="px-4 py-2 text-sm font-semibold text-white bg-red-600 rounded-md shadow-sm hover:bg-red-700 disabled:bg-red-300">Stop</button>
        </div>
      </header>

      {settings.responseLayout === ResponseLayout.Side ? (
        <div className="flex-grow flex flex-row min-h-0">
          <main className="w-2/3 pr-4 flex flex-col">
            {visualizerContent}
          </main>
          <aside className="w-1/3 pl-4 border-l border-gray-200 flex flex-col">
            <div className="flex-grow overflow-y-auto pr-2 pb-4">
              {responseButtons}
            </div>
            <div className="flex-shrink-0 pt-4 border-t border-gray-200">
              {submitButton}
            </div>
          </aside>
        </div>
      ) : (
        <>
          <main className="flex-grow flex flex-col items-center justify-center">
            {visualizerContent}
          </main>
          <footer className="mt-4 pt-4 border-t border-gray-200">
            {responseButtons}
            {submitButton}
          </footer>
        </>
      )}
    </div>
  );
};

export default Game;