
import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { GameSettings, StimulusType, PerformanceStats } from './types';
import Settings from './components/Settings';
import Game from './components/Game';
import Performance from './components/Performance';
import CreatorStudio from './components/CreatorStudio';
import { DEFAULT_SETTINGS } from './constants';
import ErrorBoundary from './components/ErrorBoundary';

type GameState = 'idle' | 'running' | 'paused' | 'finished';
type CurrentPage = 'main' | 'creator';

const loadAutoSavePreference = (): boolean => {
    try {
        const saved = localStorage.getItem('chunkCoreAutoSave');
        return saved ? JSON.parse(saved) : false;
    } catch (error) {
        console.error("Error loading auto-save preference:", error);
        return false;
    }
};

const loadNBackSettings = (autoSaveEnabled: boolean): GameSettings => {
    if (!autoSaveEnabled) return DEFAULT_SETTINGS;
    try {
        const saved = localStorage.getItem('chunkCoreNBackSettings');
        return saved ? { ...DEFAULT_SETTINGS, ...JSON.parse(saved) } : DEFAULT_SETTINGS;
    } catch (error) {
        console.error("Error loading N-Back settings:", error);
        return DEFAULT_SETTINGS;
    }
};


const App: React.FC = () => {
  const [autoSave, setAutoSave] = useState<boolean>(loadAutoSavePreference);
  const [settings, setSettings] = useState<GameSettings>(() => loadNBackSettings(autoSave));
  const [gameState, setGameState] = useState<GameState>('idle');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState<CurrentPage>('main');
  const [performance, setPerformance] = useState<PerformanceStats>({
    accuracies: {},
    overallAccuracy: 0,
    scores: {},
    bestStreak: 0,
    currentStreak: 0,
  });
  
  // Save N-Back settings if autoSave is enabled
  useEffect(() => {
    if (autoSave) {
      try {
        localStorage.setItem('chunkCoreNBackSettings', JSON.stringify(settings));
      } catch (error) {
        console.error("Error saving N-Back settings:", error);
      }
    }
  }, [settings, autoSave]);

  // Save the auto-save preference itself when it changes
  useEffect(() => {
    try {
      localStorage.setItem('chunkCoreAutoSave', JSON.stringify(autoSave));
    } catch (error) {
      console.error("Error saving auto-save preference:", error);
    }
  }, [autoSave]);

  const handleGameStart = useCallback(() => {
    setIsSettingsOpen(false); // Close settings on game start
    setGameState('running');
    setPerformance({
      accuracies: {},
      overallAccuracy: 0,
      scores: {},
      bestStreak: performance.bestStreak,
      currentStreak: 0,
    });
  }, [performance.bestStreak]);

  const handleGamePause = useCallback(() => {
    setGameState(gs => gs === 'running' ? 'paused' : 'running');
  }, []);

  const handleGameStop = useCallback(() => {
    setGameState('idle');
  }, []);
  
  const handleGameFinish = useCallback(() => {
    setGameState('finished');
  }, []);

  const handleSettingsChange = (newSettings: GameSettings) => {
    setSettings(newSettings);
  };
  
  const handlePerformanceUpdate = useCallback((newStats: PerformanceStats) => {
    setPerformance(newStats);
  }, []);

  const handleAutoSaveChange = (enabled: boolean) => {
    setAutoSave(enabled);
  };

  const activeStimuli = useMemo(() => 
    Object.entries(settings.stimuli)
      .filter(([, val]) => val.enabled)
      .map(([key]) => key as StimulusType), 
  [settings.stimuli]);

  return (
    <ErrorBoundary>
      <div className="bg-gray-100 text-gray-800 min-h-screen flex flex-col">
        {isSettingsOpen && currentPage === 'main' && (
          <Settings
            settings={settings}
            onSettingsChange={handleSettingsChange}
            isGameActive={gameState === 'running' || gameState === 'paused'}
            onClose={() => setIsSettingsOpen(false)}
            autoSave={autoSave}
            onAutoSaveChange={handleAutoSaveChange}
          />
        )}
        <header className="bg-white shadow-md z-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 grid grid-cols-3 items-center">
              {/* Left Side: Navigation */}
              <div className="flex justify-start">
                   <button 
                      onClick={() => setCurrentPage('main')}
                      disabled={currentPage === 'main'}
                      className="p-2 text-gray-600 rounded-full hover:bg-gray-200 disabled:opacity-25 disabled:cursor-not-allowed transition-opacity"
                      aria-label="Go to Main Game"
                  >
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
                      </svg>
                  </button>
              </div>
              
              {/* Center: Title */}
              <h1 className="text-2xl font-bold font-orbitron text-gray-800 text-center whitespace-nowrap">
                {currentPage === 'main' ? 'CHUNK CORE' : 'CREATOR STUDIO'}
              </h1>
              
              {/* Right Side: Navigation & Settings */}
              <div className="flex justify-end items-center space-x-2">
                  <button 
                      onClick={() => setCurrentPage('creator')}
                      disabled={currentPage === 'creator'}
                      className="p-2 text-gray-600 rounded-full hover:bg-gray-200 disabled:opacity-25 disabled:cursor-not-allowed transition-opacity"
                      aria-label="Go to Creator Studio"
                  >
                       <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                      </svg>
                  </button>
                  {currentPage === 'main' && (
                      <button onClick={() => setIsSettingsOpen(true)} className="p-2 text-gray-600 rounded-full hover:bg-gray-200" aria-label="Open settings">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                              <path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                          </svg>
                      </button>
                  )}
              </div>
          </div>
        </header>

        <main className="flex-grow w-full max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          {currentPage === 'main' ? (
             <div className="grid md:grid-cols-3 gap-6">
               <div className="md:col-span-2">
                  <Game 
                    settings={settings}
                    gameState={gameState}
                    performance={performance}
                    onGameStart={handleGameStart}
                    onGamePause={handleGamePause}
                    onGameStop={handleGameStop}
                    onGameFinish={handleGameFinish}
                    onPerformanceUpdate={handlePerformanceUpdate}
                  />
               </div>
               <div className="md:col-span-1">
                  <div className="sticky top-6 space-y-6">
                    <Performance stats={performance} activeStimuli={activeStimuli} />
                  </div>
               </div>
             </div>
          ) : (
            <CreatorStudio autoSave={autoSave} />
          )}
        </main>
      </div>
    </ErrorBoundary>
  );
};

export default App;
