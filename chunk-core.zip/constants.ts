
import { GameSettings, VisualMode, AudioGUIVisibility, ResponseLayout } from './types';
import React from 'react';

export const DEFAULT_SETTINGS: GameSettings = {
  nValue: 2,
  trials: 50,
  speed: 2500,
  adaptive: true,
  stimuli: {
    audio: { enabled: true, count: 8 },
    position: { enabled: true, count: 9 },
    color: { enabled: false, count: 8 },
    shape: { enabled: false, count: 4 },
    text: { enabled: false, count: 26 },
  },
  visualMode: VisualMode.ThreeDCube,
  audioGUIVisibility: AudioGUIVisibility.IconAndText,
  responseLayout: ResponseLayout.Bottom,
  visualizerHeight: 650,
  gridSize: 3,
  inactiveOpacity: 0.1,
  cubeGap: 20,
  cameraAngleX: -35,
  sphereCount: 20,
  respawnSphere: true,
  sphereSpeed: 5,
  interferenceEnabled: false,
  interferencePercentage: 10,
};

// C4 to C5 musical notes
export const TONES: number[] = [
  261.63, 293.66, 329.63, 349.23, 392.00, 440.00, 493.88, 523.25,
];

// High-contrast, identifiable colors
export const COLORS: string[] = [
  '#EF4444', // red-500
  '#F97316', // orange-500
  '#EAB308', // yellow-500
  '#22C55E', // green-500
  '#3B82F6', // blue-500
  '#8B5CF6', // violet-500
  '#EC4899', // pink-500
  '#F4F4F5', // zinc-100 (white-ish)
];

// Basic SVG shapes as React components
const Circle: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  React.createElement('svg', { viewBox: '0 0 100 100', ...props },
    React.createElement('circle', { cx: "50", cy: "50", r: "45", fill: "currentColor", stroke: "none" })
  )
);
const Square: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  React.createElement('svg', { viewBox: '0 0 100 100', ...props },
    React.createElement('rect', { x: "5", y: "5", width: "90", height: "90", fill: "currentColor", stroke: "none" })
  )
);
const Triangle: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  React.createElement('svg', { viewBox: '0 0 100 100', ...props },
    React.createElement('polygon', { points: "50,5 95,95 5,95", fill: "currentColor", stroke: "none" })
  )
);
const Star: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  React.createElement('svg', { viewBox: '0 0 100 100', ...props },
    React.createElement('polygon', { points: "50,5 61,40 98,40 68,62 79,96 50,75 21,96 32,62 2,40 39,40", fill: "currentColor", stroke: "none" })
  )
);

export const SHAPES: React.FC<React.SVGProps<SVGSVGElement>>[] = [
  Circle,
  Square,
  Triangle,
  Star,
];

export const LETTERS: string[] = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');